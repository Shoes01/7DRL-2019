class Status():
    def __init__(self):
        self.stunned = 0
        self.healing = 0
        self.healing_power = 0