class Inventory():
    def __init__(self):
        self.contents = []
        self.selected = None