### 7DRL 2019 ###

[GOALS]

__Goal 1__
Controls are hyper-streamlined.

Controls:
    Numpad: movement
    num_5: wait, or interact with item
    qweads: activate skill

    esc: exit

    need a way to drop items. Space bar over nothing? not a bad idea! always swaps, even with nothing...

All other information is on the HUD.

<what about damage?> Killing enemies returns HP. Killing many per turn grants more HP? Revenge kills grant more HP? <lore> When a soul leaves a body, you absorb some of that ... energy ...

__Goal 3__
Skills are interesting.
Enemies use the skills too???

Gameplay has the player taking on huge numbers of lowly creatures, and a few heroic opponents.

__Goal 3.1__
Allow some items to use stats negatively, so that the player may actually try to bottom out some stats and use the negative values for a great bonus...