### ITEMS ###

___ LOOT SYSTEM ___
Items don't really vary...

Monsters will have static equipment for their race/job. <todo> A race may only have access to certain jobs. Job rarity will drive item rarity!
Monsters will have items equipped based on their rank.
Monsters will drop what is in their inventory and what they have equipped.
Monsters will not drop items the player is already wearing.
Dropped items will not stack; they will each find their own unoccupied space.

___ ITEM TYPES ___
Item types, and their role

[MAIN_HAND]
Provides a passive buff to the bump attack.
Provides an offensive action skill.

[TORSO]
Provides a pass buff to defense.
Provides a defensive buff skill

[OFF_HAND]
Provides a defensive action skill

[HEAD]
Provides an offensive buff skill

[RING_FINGER]
Provides a special skill

[FEET]
Provides a movement action skill

___ SKILLS ___
[OFFENSIVE_ACTION]
Pierce attack
Lunge attack
Sweep atatck
Leap attack

Fireball attack
Arc lightning attack

[DEFENSIVE_ACTION]
Counter incoming ATK attacks
Block incoming ATK attacks

Mirror incoming MAG attacks
Shield incoming MAG attacks

[OFFENSIVE_BUFF]
Warcry: Increases ATK
Fury: Increases ATK, reducdes DEF

[DEFENSIVE_BUFF]
Resolution: increases DEF and RES

[MOVEMENT_ACTION] - Actions may provides a SPD buff too.
Leap
Charge
Knockback

[SPECIAL]
Regain full HP
Nova blast
