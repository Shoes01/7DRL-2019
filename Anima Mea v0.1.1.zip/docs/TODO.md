##### TODO ######

#####--------------------------- MVP 0.1.0

Move to a GameWon state

#####--------------------------- MVP 0.2.0

# STATES

Have a game start state
Have a game win state
Have a dead state

#####--------------------------- MVP 0.3.0

# GUI

Improve compare screen
>>> Display skill
>>> Display legend or whatever...
>>> Create one for the rest of the items

Improve Charachter sheet

Add a message to the log when a player equips or switches an item

Using skills should update the log

Revisit how skills are drawn when they are first clicked
>>> Instead of drawing all 8 directions, draw arrows showing direction choices
>>> Distance of arrows should reflect size of area

#####--------------------------- MVP 0.4.0

# CONTENT

Add more skills
Add more items
Add more monsters

#####--------------------------- MVP 0.5.0

# FEEDBACK

Somehow display that blows are being delivered
> Flash the status of every entity?

Give instructions to the player about the controls
> Space bar is to "interact" or to stop "interact"ing. 
> NUM_5 or NUM_ENTER is to confirm interaction
> NUM_PAD is for movement, NUM_5 for wait
> QWEASD are for skills

#####--------------------------- MVP 0.6.0

# GUI++++

Character creation screen
> Would simply be a game state with its own input

After some overkill gibbing :3

#####--------------------------- MVP 0.7.0

# ADDITIONAL MECHANIC???

Charge up attacks... certain skills have a cooldown that only reduce when they kill or hit others

#####--------------------------- MVP 1.0.0

# BALANCE

Make the game fun?